//
// Created by Guy on 3/19/2018.
//

#ifndef HW1_UTILS_H
#define HW1_UTILS_H
int createNumByldx(int indices, int num);
int findLength(int n);
int getDigit(int num, int digit);
int checkIndices(int indice,int numLength);
int createNumByIdx(int indices, int num);
int createNumByReverseIdx(int indices, int num);
int getNumAndCheckValidation ();
int getReverseDigit(int num, int digit);
#endif //HW1_UTILS_H
