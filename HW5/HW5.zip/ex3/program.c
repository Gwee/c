#include<stdio.h>
#include <stdlib.h>
#include "struct.h"
TNode* buildTree(LLNode* node);
LNode* add(LNode* head, int t);
TNode* addElm(TNode *root, int p);
LLNode* add2(LLNode * head, LNode * t);

int main() {
	LNode* l1 = NULL;
	LNode* l2 = NULL;
	LNode* l3 = NULL;
	LNode* l4 = NULL;
	LLNode* all = NULL;
	l1 = add(l1, 9);
	l1 = add(l1, 4);
	l1 = add(l1, 2);
	l2 = add(l2, 9);
	l2 = add(l2, 4);
	l2 = add(l2, 6);
	l2 = add(l2, 5);
	l3 = add(l3, 9);
	l3 = add(l3, 4);
	l3 = add(l3, 6);
	l3 = add(l3, 8);
	l3 = add(l3, 7);
	l4 = add(l4, 9);
	l4 = add(l4, 12);
	l4 = add(l4, 17);
	all = add2(all, l1);
	all = add2(all, l2);
	all = add2(all, l3);
	all = add2(all, l4);

	TNode* root;
	root = buildTree(all);

	getchar();
	return 0;
}