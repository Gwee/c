typedef  struct  HNode {
	char  chr;
	struct HNode *left, *right;
} HNode;

typedef  struct {
	char chr;
	int counter;
}Symbol;
