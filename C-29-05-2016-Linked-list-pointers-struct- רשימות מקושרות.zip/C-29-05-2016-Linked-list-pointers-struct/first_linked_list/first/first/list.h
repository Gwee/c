typedef struct List {
	int info;
	struct List *next;
}List;

List* add(List *head, int info);
void show(List *);
List* reverse(List*);
List* removee(List* head, int x);
